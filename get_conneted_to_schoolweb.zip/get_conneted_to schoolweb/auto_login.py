import time
from  selenium import webdriver
import subprocess
import win32ctypes
def login(username,password):
    options = webdriver.FirefoxOptions()
    options.add_argument('--headless')
    driver = webdriver.Firefox(options=options)
    href = 'https://login.ecnu.edu.cn'
    driver.get(href)
    time.sleep(4)
    name_input = driver.find_element_by_xpath('/html/body/div/div/div[2]/form/table/tbody/tr[2]/td[2]/input')
    name_input.send_keys(username)
    password_input = driver.find_element_by_xpath('/html/body/div/div/div[2]/form/table/tbody/tr[3]/td[2]/input')
    password_input.send_keys(password)

    click = driver.find_element_by_xpath('/html/body/div/div/div[2]/form/table/tbody/tr[4]/td[2]/p/input[1]')
    click.click()
    driver.close()
    print('login successfully')


def is_connected():
    res = subprocess.call('ping 119.75.217.109 -n 1', shell=True)
    return False if res else True


if __name__=="__main__":
    try:
        f = open('log_info.txt','r')
        lists = f.readlines()
        username = lists[0]
        password = lists[1]
    except FileNotFoundError:
        username = input('Please Input Your account:')
        password = input('Please Input Your password:')
        F = open('log_info.txt', 'w')
        F.write(username+'\n'+password+'\n')
        F.close()
        #win32ctypes.windll.kernel32.SetFileAttributesW('log_info.txt', 2)
    while True:
        print('Hi,I am working!')
        if not is_connected():
            print('Try to login automatically')
            login(username,password)
        time.sleep(300)

